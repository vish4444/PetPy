from hangman_lib import *

#
# This file is just a demo of the functions in hangman_lib.
#

help(print_hangman_image)

print_hangman_image(0)
print
print_hangman_image(1)
print
print_hangman_image(2)
print
print_hangman_image(3)
print
print_hangman_image(4)
print
print_hangman_image(5)
print
print_hangman_image(6)

print
print

